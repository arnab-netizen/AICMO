# Morgan Lee
Demographics: 30–45, Business decision-maker at mid-market organization
Psychographics: Data-conscious and strategic. Seeks solutions that are reliable, scalable, and demonstrate clear value. Skeptical of hype; prefers proven approaches.
Pain points: Workflow inefficiency, Team coordination, Balancing workflow inefficiency with other priorities, Measuring impact of team coordination
Triggers: Seeing competitors succeed with better workflow inefficiency, Pressure from leadership to improve launch new saas product, Team members asking for workflow inefficiency solutions, Case studies from industry peers demonstrating results
Objections: Will this require significant team training or overhead?, How does this integrate with our current systems?, Can we see concrete results in our first 30 days?, Is the vendor committed long-term, or is this another trend?
Content preferences: Data-backed case studies and ROI examples, Webinars and live demos showing real use, Short-form tips and actionable advice, Peer reviews and community recommendations, Thought leadership on industry trends
Primary platforms: LinkedIn, Twitter
Tone preference: Innovative, Reliable
